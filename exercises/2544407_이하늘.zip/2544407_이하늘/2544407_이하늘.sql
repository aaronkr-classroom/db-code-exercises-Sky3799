-- DB Final Project Skeleton
-- Student Name: 이하늘
-- Student ID: 2544407

-- CREATE TABLE
CREATE TABLE class_code (
    code  NUMERIC(1) PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

CREATE TABLE task_code (
    code NUMERIC(1) PRIMARY KEY,
    task VARCHAR(30)
);

CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,
    name   VARCHAR(20) NOT NULL,
    cell   CHAR(13) NOT NULL UNIQUE,
    addr   VARCHAR(100),
    c_code NUMERIC(1) DEFAULT 3,
    FOREIGN KEY (c_code) REFERENCES class_code(code)
);

CREATE TABLE staff (
    staff_id  NUMERIC(5) PRIMARY KEY,
    name      VARCHAR(20) NOT NULL,
    birthday  NUMERIC(6) NOT NULL,
    tel       CHAR(12),
    salary    NUMERIC(9),
    t_code    NUMERIC(1) NOT NULL,
    hire_date CHAR(8) NOT NULL,
    FOREIGN KEY (t_code) REFERENCES task_code(code)
);

CREATE TABLE tour (
    tour_num   CHAR(8) PRIMARY KEY,
    departure  VARCHAR(50) NOT NULL,
    arrival    VARCHAR(50) NOT NULL,
    program    VARCHAR(100),
    start_dt   DATE NOT NULL,
    end_dt     DATE NOT NULL,
    min_num    NUMERIC(2),
    max_num    NUMERIC(2),
    expense    NUMERIC(7) NOT NULL,
    deposit    NUMERIC(6),
    dept_yn    CHAR(1) DEFAULT 'N',
    staff_id   NUMERIC(5),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

CREATE TABLE reserve (
    cus_id   VARCHAR(15),
    tour_num CHAR(8),
    res_date CHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'),
    dep_yn   CHAR(1) DEFAULT 'N',
    exp_yn   CHAR(1) DEFAULT 'N',
    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- bonus
CREATE TABLE tour_bus (
    bus_id   NUMERIC(2) PRIMARY KEY,
    seat     NUMERIC(2),
    del_year NUMERIC(4)
);

CREATE TABLE driver (
    driver_id NUMERIC(5) PRIMARY KEY,
    name      VARCHAR(20) NOT NULL,
    birthday  CHAR(6) NOT NULL,
    cell      CHAR(13) NOT NULL,
    pay       NUMERIC(5) DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

CREATE TABLE assign_driver (
    tour_num  CHAR(8) PRIMARY KEY,
    driver_id NUMERIC(5),
    work_hour NUMERIC(3),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

CREATE TABLE assign_bus (
    tour_num CHAR(8) PRIMARY KEY,
    bus_id   NUMERIC(2),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);



-- INSERT DATA

-- class_code
INSERT INTO class_code VALUES (1, '최우수', '연간 500만원 이상');
INSERT INTO class_code VALUES (2, '우수',   '연간 200만원 이상');
INSERT INTO class_code VALUES (3, '일반',   '기본 등급');

-- task_code
INSERT INTO task_code VALUES (1, '여행상품관리');
INSERT INTO task_code VALUES (2, '예약관리');
INSERT INTO task_code VALUES (3, '관광버스배차관리');
INSERT INTO task_code VALUES (4, '직원관리');
INSERT INTO task_code VALUES (5, '고객관리');

-- customer
INSERT INTO customer VALUES ('C001', '김민준', '010-1111-2222', '서울특별시 강남구', 1);
INSERT INTO customer VALUES ('C002', '이서연', '010-2222-3333', '서울특별시 마포구', 2);
INSERT INTO customer VALUES ('C003', '박지훈', '010-3333-4444', '부산광역시 해운대구', 3);
INSERT INTO customer VALUES ('C004', '최유진', '010-4444-5555', '대구광역시 수성구', 2);
INSERT INTO customer VALUES ('C005', '정하늘', '010-5555-6666', '인천광역시 연수구', 1);

-- staff
INSERT INTO staff VALUES (10001, '한지민', 900101, '02-1111-2222', 3200000, 1, '20180301');
INSERT INTO staff VALUES (10002, '오세훈', 880515, '02-2222-3333', 3500000, 2, '20170612');
INSERT INTO staff VALUES (10003, '윤아름', 920722, '02-3333-4444', 3000000, 3, '20190420');
INSERT INTO staff VALUES (10004, '강민호', 850909, '02-4444-5555', 4200000, 4, '20150110');
INSERT INTO staff VALUES (10005, '서지우', 950330, '02-5555-6666', 2900000, 5, '20210905');

-- tour
INSERT INTO tour VALUES ('T0000001', '서울', '부산', 'http://tour.example.com/program1', '2026-07-01', '2026-07-03', 10, 30, 250000, 50000, 'N', 10001);
INSERT INTO tour VALUES ('T0000002', '서울', '제주', 'http://tour.example.com/program2', '2026-07-10', '2026-07-13', 15, 40, 450000, 80000, 'N', 10002);
INSERT INTO tour VALUES ('T0000003', '부산', '경주', 'http://tour.example.com/program3', '2026-08-01', '2026-08-02', 10, 25, 150000, 30000, 'Y', 10001);
INSERT INTO tour VALUES ('T0000004', '인천', '강릉', 'http://tour.example.com/program4', '2026-08-15', '2026-08-17', 8,  20, 300000, 60000, 'N', 10003);
INSERT INTO tour VALUES ('T0000005', '대구', '전주', 'http://tour.example.com/program5', '2026-09-01', '2026-09-02', 10, 30, 180000, 40000, 'N', 10002);

-- reserve
INSERT INTO reserve VALUES ('C001', 'T0000001', '20260601', 'Y', 'N');
INSERT INTO reserve VALUES ('C002', 'T0000001', '20260602', 'Y', 'Y');
INSERT INTO reserve VALUES ('C003', 'T0000002', '20260603', 'N', 'N');
INSERT INTO reserve VALUES ('C004', 'T0000003', '20260604', 'Y', 'N');
INSERT INTO reserve VALUES ('C005', 'T0000004', '20260605', 'Y', 'Y');

-- 보너스
-- tour_bus
INSERT INTO tour_bus VALUES (1, 28, 2022);
INSERT INTO tour_bus VALUES (2, 45, 2020);
INSERT INTO tour_bus VALUES (3, 28, 2023);
INSERT INTO tour_bus VALUES (4, 45, 2021);
INSERT INTO tour_bus VALUES (5, 28, 2024);

-- driver
INSERT INTO driver VALUES (1, '문도윤', '870203', '010-6666-7777', 15000, '20230101', '12');
INSERT INTO driver VALUES (2, '배수아', '910612', '010-7777-8888', 16000, '20220601', '24');
INSERT INTO driver VALUES (3, '장태양', '890925', '010-8888-9999', 15000, '20210315', '18');
INSERT INTO driver VALUES (4, '고은별', '930418', '010-9999-0000', 17000, '20240101', '6');
INSERT INTO driver VALUES (5, '남도현', '860730', '010-0000-1111', 15000, '20200910', '36');

-- assign_driver
INSERT INTO assign_driver VALUES ('T0000001', 1, 40);
INSERT INTO assign_driver VALUES ('T0000002', 2, 48);
INSERT INTO assign_driver VALUES ('T0000003', 3, 20);
INSERT INTO assign_driver VALUES ('T0000004', 4, 30);
INSERT INTO assign_driver VALUES ('T0000005', 5, 25);

-- assign_bus
INSERT INTO assign_bus VALUES ('T0000001', 1);
INSERT INTO assign_bus VALUES ('T0000002', 2);
INSERT INTO assign_bus VALUES ('T0000003', 3);
INSERT INTO assign_bus VALUES ('T0000004', 4);
INSERT INTO assign_bus VALUES ('T0000005', 5);


-- INDEX  (인덱스 정의서 기준)

CREATE INDEX tour_arrival_idx ON tour(arrival);

CREATE INDEX driver_name_idx ON driver(name);



-- TEST QUERIES
-- 고객 등급 검색 (입력: id)
SELECT c.name, cc.class
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'C001';

-- 직원 담당업무 검색 (입력: 사번)
SELECT s.name, tc.task
FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10001;

-- 여행상품 예약 고객 검색 (입력: 여행번호)
SELECT c.name, r.res_date, r.dep_yn
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'T0000001';

-- 여행상품 배정 운전기사 검색 (입력: 여행번호)
SELECT t.departure, d.name, d.cell
FROM tour t
JOIN assign_driver ad ON t.tour_num = ad.tour_num
JOIN driver d ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'T0000001';

-- 고객 데이터 삽입
INSERT INTO customer (cus_id, name, cell)
VALUES ('C006', '윤하늘', '010-1212-3434');

-- 직원 급여 변경 (입력: 사번 / 20만원 증가)
UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10001;

-- 급여 변경 확인용 조회
select salary from staff
where staff_id = 10001;

-- 예약 정보 삭제 (입력: 고객id, 여행번호)
DELETE FROM reserve
WHERE cus_id = 'C002' AND tour_num = 'T0000001';


-- DROP TABLE
DROP TABLE IF EXISTS assign_bus;
DROP TABLE IF EXISTS assign_driver;
DROP TABLE IF EXISTS reserve;
DROP TABLE IF EXISTS tour_bus;
DROP TABLE IF EXISTS driver;
DROP TABLE IF EXISTS tour;
DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS class_code;
DROP TABLE IF EXISTS task_code;